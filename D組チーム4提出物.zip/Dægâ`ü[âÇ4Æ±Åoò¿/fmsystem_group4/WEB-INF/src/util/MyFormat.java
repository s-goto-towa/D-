package util;

import java.text.DecimalFormat;

public class MyFormat {

	// 引数に受け取った金額データを「￥付き、３桁カンマ区切り」の形式に変換するインスタンスメソッド
	public String moneyFormat(int price) {

		DecimalFormat money = new DecimalFormat("\\###,###");

		return money.format(price);
	}
}
