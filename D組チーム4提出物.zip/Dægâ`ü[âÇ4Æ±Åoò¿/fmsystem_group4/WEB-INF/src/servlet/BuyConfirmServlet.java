package servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.*;
import bean.*;
import dao.*;
import util.*;

//取引情報下記人機能
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 各種インスタンス化
		UserDAO userDao = new UserDAO();
		GoodsDAO goodsDao = new GoodsDAO();
		AddressDAO addressDao = new AddressDAO();
		Goods goods = new Goods();
		//変更
		User seller = new User();
		//変更終わり
		Address buyeraddress = new Address();
		SendMail sendMail = new SendMail();// メール送信

		// エラーメッセージ
		String error = "";
		String cmd = "";

		// 遷移元を判断するコマンド
		String input = "";

		//セッションからユーザー情報を受け取る
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");

		//グッズIDを取得
		String sGoods_id = request.getParameter("goods_id");

		int goods_id = Integer.parseInt(sGoods_id);

		try {
			// セッション切れの判定をする
			if (user == null) {
				cmd = "logout";
				error = "セッションが切れました";
				return;
			}

			//商品IDから詳細検索する
			goods = goodsDao.selectByGoods_id(goods_id);//商品IDから購入者IDを取得（Goods.java）

			// 購入が押されたら、出品者にメールを送信する
			input = request.getParameter("input");//購入IDから住所を取得(User.java)
			if(input.equals("buy")) {

				//購入者情報を登録する
				goodsDao.updateBuyer_id(goods.getGoods_id(), user.getUser_id());

				// 現在日時情報で初期化されたインスタンスの生成
				Date dateObj = new Date();
				SimpleDateFormat format = new SimpleDateFormat( "yyyy/MM/dd HH:mm" );
				// 日時情報を指定フォーマットの文字列で取得
				String buy_date = format.format( dateObj );

				//購入情報ををGoodsオブジェクトに格納する
				goods.setBuyer_id(user.getUser_id());
				goods.setBuy_date(buy_date);

				//出品者の情報を読みだす
				seller = userDao.selectByUser(goods.getUser_id());
				//出品者の利益を更新
				userDao.updateProfits(seller.getUser_id(), seller.getProfits(), goods.getPrice());

				//住所の検索
				buyeraddress = addressDao.selectByAddress(goods.getBuyer_id());

				//変更
				// メール本文
				String goodsdetail = "商品番号：" + goods.getGoods_id()
						+ "\n商品名：" + goods.getGoods_name()
						+ "\n商品説明："+ goods.getGoods_description()
						+ "\n価格：" + goods.getPrice() + "円"
						+ "\n送付先：" + buyeraddress.getPost_code()
						+ "\n		" + buyeraddress.getPrefectures()
						+ "\n		" + buyeraddress.getMunicipality()
						+ "\n		" + buyeraddress.getStreet() + buyeraddress.getBuilding() + buyeraddress.getRoom_number() + "\n\n";
				//変更終わり

				String mailtext = user.getNickname() + "様\n"
						+ "いつもご利用いただき誠にありがとうございます。\n\n"
						+ goodsdetail
						+ "上記商品の注文を確認致しました。\n"
						+ "入金状況が更新され次第、順次発送をお願いします。";

				sendMail.SendMail(mailtext,seller.getMail_address());
			}

		} catch (IllegalStateException e) {

			cmd = "logout";
			error = "DB接続エラーになりました";

		} finally {
			if (error.equals("")) {// エラーがない時
				// goodsをリクエストスコープに登録し、buyConfirm.jspにフォワードする

				//変更
				//購入したときuserTypeをリクエストスコープに登録
				if(input.equals("buy")) {
					request.setAttribute("userType", "buy");

					//出品者が発送・入金状況を確認するとき
				}else if(input.equals("seller")) {
					request.setAttribute("input", input);

					//購入者が発送・入金状況を確認するとき
				}else {
					request.setAttribute("input", input);
				}
				//変更終わり
				request.setAttribute("goods", goods);
				request.getRequestDispatcher("view/buyConfirm.jsp").forward(request, response);

			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}
	}
}
