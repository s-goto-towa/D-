package servlet;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import bean.*;
import dao.*;
import util.*;

//取引情報更新機能
public class TradeUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//各種インスタンス化
		GoodsDAO goodsDao = new GoodsDAO();
		UserDAO userDao = new UserDAO();
		AddressDAO addressDao = new AddressDAO();
		Address buyeraddress = new Address();
		SendMail sendMail = new SendMail();// メール送信
		User buyuser = new User();//購入者のユーザー情報


		//エラーメッセージ
		String error = "";
		String cmd = "";

		//jspで表示するための変数
		int update = 0;

		//ユーザーを判断するコマンド
		String userType = "";

		Goods  goods = new Goods();

		try {
			//セッション切れの判定をする
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");
			if(user == null) {
				cmd = "logout";
				error = "セッションが切れました";
				return;
			}

			//商品idを受け取る
			String sGoods_id = request.getParameter("goods_id");

			// int型に変換
			int goods_id = Integer.parseInt(sGoods_id);

			// goods_idから商品情報を取得
			goods = goodsDao.selectByGoods_id(goods_id);

			//商品情報がないとき
			if(goods.getUser_id() == null) {
				cmd = "menu";
				error = "商品情報が無いため、取引状況は更新できません。";
				return;
			}
			//購入者or出品者の情報を取得
			userType = request.getParameter("userType");

			//購入者か出品者の情報をリクエストスコープに登録する
			request.setAttribute("input", userType);

			//userTypeが送られてないとき
			if(userType == null) {
				cmd = "menu";
				error = "購入者又は出品者情報が無いため、取引状況は更新できません。";
				return;
			}

			//更新ボタン押下後
			update =Integer.parseInt(request.getParameter("update"));
			if(update != 0) {

				//商品IDをもとに入金情報or発送情報をデータベースに登録する
				//購入者の時、入金情報（0：入金前、1：入金完了） payment_statusを登録する
				if(userType.equals("buyer")) {
					//データベースに登録
					goodsDao.updatePayment_status(goods.getGoods_id(), update);
					goods.setPayment_status(update);
				}

				//出品者の時、発送状況（0：発送前、1：発送完了、２：発送中） ship_statusを登録する
				if(userType.equals("seller")) {
					//データベースに登録
					goodsDao.updateShip_status(goods.getGoods_id(), update);
					goods.setShip_status(update);

					//「1：発送中」の時、購入者に発送メールを送信する
					if(update == 1) {

						//商品IDから詳細検索する
						goods = goodsDao.selectByGoods_id(goods.getGoods_id());//商品IDから購入者IDを取得（Goods.java）

						//購入者情報がないとき
						if(goods.getBuyer_id() == null) {
							cmd = "menu";
							error = "購入者情報が無いため、取引状況は更新できません。";
							return;
						}

						//購入者の情報を取得
						buyuser = userDao.selectByUser(goods.getBuyer_id());
						//住所の検索
						buyeraddress = addressDao.selectByAddress(goods.getBuyer_id());//購入IDから住所を取得(User.java)

						// メール本文
						String goodsdetail = "商品番号：" + goods.getGoods_id()
						+ "\n商品名：" + goods.getGoods_name()
						+ "\n商品説明："+ goods.getGoods_description()
						+ "\n送付先：" + buyeraddress.getPost_code()
						+ "\n		" + buyeraddress.getPrefectures()
						+ "\n		" + buyeraddress.getMunicipality()
						+ "\n		" + buyeraddress.getStreet() + buyeraddress.getBuilding() + buyeraddress.getRoom_number() + "\n\n";

						String mailtext = buyuser.getLast_name() + "様\n"
								+ "この度はご利用いただき誠にありがとうございます。\n\n"
								+ goodsdetail
								+ "上記商品が出品者様より発送されました。\n";

						//メールを送信
						sendMail.SendMail(mailtext, buyuser.getMail_address());//購入者へ
					}
				}
			}

			//商品IDが文字のとき
		}catch(NumberFormatException e) {
			error = "商品IDが不正の為、書籍登録処理は行えませんでした。";
			cmd = "menu";

			//データベースに接続できなかったとき
		}catch(IllegalStateException e){
			cmd = "logout";
			error = "DB接続エラーになりました";

		}finally {

			if(error.equals("")) {//エラーがない時

				if(!userType.equals("")) {
					//userTypeをリクエストスコープに登録し、tradeUpdate.jspにフォワード

					/*request.setAttribute("message1", message1);
					request.setAttribute("message2", message2);*/

					//リクエストスコープに登録する

					request.setAttribute("goods", goods);
					request.setAttribute("userType", userType);
					request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response);


				}else{//エラーがある時
					// error.jspにフォワードする
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}

		}
	}
}
