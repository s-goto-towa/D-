package servlet;

/*
 * プログラム名：出品確認機能
 * プログラムの説明：出品した商品の情報を確認できる
 * 作成者：矢部 幹太
 * 作成日：2022年6月21日
 */

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;
import dao.UserDAO;

public class ListingConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// 画面から送信される情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// セッションからuserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");

			// DAOクラスをインスタンス化
			GoodsDAO goodsDao = new GoodsDAO();

			// 出品登録画面から出品した商品のGoods_idを取得
			Goods goods = (Goods)request.getAttribute("goods");

			// 出品商品情報一覧画面からの確認したい商品のGoods_idを取得
			String sGoods_id2 = (String)request.getParameter("goods_id");

			if(!(sGoods_id2 == null)) {
				// int型に変換
				int goods_id2 = Integer.parseInt(sGoods_id2);

				// selectByGoods_id()で商品情報を取得
				goods = goodsDao.selectByGoods_id(goods_id2);


				// リクエストスコープに登録
				request.setAttribute("goods", goods);
				request.setAttribute("info", "info");

			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入は出来ません。";
			// cmd
			cmd = "error";
		} finally {

			// エラーメッセージを登録
			request.setAttribute("error", error);

			// cmd登録
			request.setAttribute("cmd", cmd);

			// エラーの有無で遷移先の判定
			if (!error.equals("")) {
				// error.jsp
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				// listingConfirm.jsp
				request.getRequestDispatcher("/view/listingConfirm.jsp").forward(request, response);
			}

		}

	}
}
