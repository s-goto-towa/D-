package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;

public class InsertGoodsServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd ="";

		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// DTOオブジェクト宣言
			Goods goods = new Goods();
			// DAOオブジェクト宣言
			GoodsDAO goodsDao = new GoodsDAO();

			// セッションからuserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			// 取得したセッションがセッション切れの場合エラー
			if (user == null) {
				error = "セッション切れの為、出品は出来ません。";
				cmd = "logout";
				return;
			}

			// パラメータの取得
			String goods_name = request.getParameter("goods_name");
			if(goods_name.length()>40){
				error="商品の名前は40文字以下で入力してください。";
				cmd="listing";
				return;
			}
			if(goods_name.equals("")){
				error="商品の名前を入力してください。";
				cmd="listing";
				return;
			}

			String description = request.getParameter("goods_description");
			if(description.length()>1000){
				error="商品の説明は1000文字以下で入力してください。";
				cmd="listing";
				return;
			}
			String districts = request.getParameter("sale_districts");
			if(districts.length()>20){
				error="出品地域は20文字以下で入力してください。";
				cmd="listing";
				return;
			}
			String category = request.getParameter("category");
			String sPrice = request.getParameter("price");
			if(sPrice.equals("")){
				error="価格を500円以上で入力してください。（数字のみ）";
				cmd="listing";
				return;
			}
			String goods_status = request.getParameter("goods_status");
			String shipping_methods = request.getParameter("shipping_methods");
			String sShip_days = request.getParameter("ship_days");

			// int型に変換
			int price = Integer.parseInt(sPrice);
			if (price < 500) {
				error = "価格が500円未満であると出品出来ません。";
				cmd = "listing";
				return;
			}
			int ship_days = Integer.parseInt(sShip_days);

			// goodsInfoオブジェクトにリクエストスコープのデータ登録
			goods.setUser_id(user.getUser_id());
			goods.setGoods_name(goods_name);
			goods.setGoods_description(description);
			goods.setSale_districts(districts);
			goods.setCategory(category);
			goods.setPrice(price);
			goods.setGoods_status(goods_status);
			goods.setShipping_methods(shipping_methods);
			goods.setShip_days(ship_days);

			// DAOオブジェクトのinsertメソッドにgoodsを引数として与える
			goodsDao.insert(goods);

			request.setAttribute("goods", goods);
			request.setAttribute("info", "insert");

			//商品IDが文字のとき
		}catch(NumberFormatException e) {
			error = "価格に文字が含まれています。数字で入力してください。";
			cmd = "listing";

		} catch (IllegalStateException e) {
			cmd = "logout";
			error = "DB接続エラーの為、登録できませんでした。";

		} catch (Exception e) {
			cmd = "logout";
			error = "予期せぬエラーが発生しました。<br>" + e;

		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/listingconfirm").forward(request, response);

			} else {

				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}