package servlet;

/*
 * プログラム名：出品確認機能
 * プログラムの説明：出品した商品の情報を確認できる
 * 作成者：矢部 幹太
 * 作成日：2022年6月21日
 */

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;
import dao.UserDAO;

public class ListingInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)

			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// 画面から送信される情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// セッションからuserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// 取得したセッションがセッション切れの場合エラー
			if (user == null) {
				error = "セッション切れの為、出品は出来ません。";
				cmd = "logout";
				return;
			}


			// DAOクラスをインスタンス化
			GoodsDAO goodsDao = new GoodsDAO();


			// goodsDAOのselectAllメソッド実行し戻り値をgoods_listに格納
			ArrayList<Goods> goods_list = goodsDao.selectByuser_id(user.getUser_id());

			// リクエストスコープに登録
			request.setAttribute("goods_list", goods_list);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、出品一覧を表示できません。";
			// cmd
			cmd = "logout";
		} finally {

			// エラーメッセージを登録
			request.setAttribute("error", error);

			// cmd登録
			request.setAttribute("cmd", cmd);

			// エラーの有無で遷移先の判定
			if (!error.equals("")) {
				// error.jsp
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				// listingConfirm.jsp
				request.getRequestDispatcher("/view/listingInfo.jsp").forward(request, response);
			}

		}

	}
}
