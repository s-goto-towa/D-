package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Goods;
import bean.User;
import dao.GoodsDAO;
import dao.UserDAO;

public class GoodsDetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラーメッセージとcmd情報を管理する変数
		String error = "";
		String cmd = ""; // フォワード先を区別


		try {
			//セッションでユーザー情報を受け取る
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");
			//セッション切れかチェック
			if(user == null) {
				cmd = "logout";
				error = "セッションが切れました";
				return;
			}

			// 画面から送信される情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			String strGoods_id = request.getParameter("goods_id");

			int goods_id= Integer.parseInt(strGoods_id);

			// userDAOとgoodsDAOクラスのオブジェクトを生成しデータベースに接続
			GoodsDAO goodsObj = new GoodsDAO();
			UserDAO userDAO = new UserDAO();

			// 表示する情報を格納するUserオブジェクトを生成
			// UserDAOクラスに定義したselectByUser（）メソッドを利用して情報を取得
			Goods goods = goodsObj.selectByGoods_id(goods_id);

			//出品者のニックネームを取り出す
			User seller = userDAO.selectByUser(goods.getUser_id());

			// 取得した情報をリクエストスコープに登録
			request.setAttribute("nickname", seller.getNickname());
			request.setAttribute("goods", goods);

			// 詳細情報のエラーチェック

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、表示できませんでした。";
			cmd = "logout";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (cmd.equals("")) {
				request.getRequestDispatcher("/view/goodsDetail.jsp").forward(request, response);
			} else {
				// エラーのある場合はerror.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
