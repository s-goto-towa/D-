package servlet;

/*
 * プログラム名：出品確認機能
 * プログラムの説明：出品した商品の情報を確認できる
 * 作成者：矢部 幹太
 * 作成日：2022年6月22日
 */

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserListServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// DAOクラスをインスタンス化
			UserDAO userDao = new UserDAO();

			// User型のArrayListを作成しselectAllメソッドを実行
			ArrayList<User> user_list = userDao.selectAll();

			// リクエストスコープに登録
			request.setAttribute("user_list", user_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー一覧を表示出来ません。";
		} finally {

			// エラーメッセージを登録
			request.setAttribute("error", error);

			// cmd登録
			request.setAttribute("cmd", cmd);

			// エラーの有無で遷移先の判定
			if (!error.equals("")) {
				// error.jsp
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				// userlist.jsp
				request.getRequestDispatcher("/view/userList.jsp").forward(request, response);
			}

		}

	}
}
