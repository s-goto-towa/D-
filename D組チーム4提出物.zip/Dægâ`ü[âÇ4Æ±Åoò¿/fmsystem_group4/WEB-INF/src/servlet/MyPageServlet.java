package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Address;
import bean.User;
import dao.AddressDAO;
import dao.UserDAO;

public class MyPageServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		//エラーメッセージと遷移情報を宣言
		String error = "";
		String cmd = "";

		//セッションでユーザー情報を受け取る
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");

		//UserDAOオブジェクトを生成する
		UserDAO userDao = new UserDAO();

		//Addressオブジェクトを生成する
		Address address = new Address();
		//AddressDAOオブジェクトを生成する
		AddressDAO addressDao = new AddressDAO();


		try {
			//セッション切れかチェック
			if(user == null) {
				cmd = "logout";
				error = "セッションが切れました";
				return;
			}

			String user_id = "";
			if(user.getAuthority() == 2) {	//会員のとき
				user_id = user.getUser_id();

			}else {	//管理者のとき
				user_id = request.getParameter("user_id");
			}

			//アカウント情報を読みだす
			user = userDao.selectByUser(user_id);
			address = addressDao.selectByAddress(user_id);

			//ユーザー情報がないときエラー
			if(user.getUser_id() == null || address.getUser_id() == null) {
				error = "ユーザー情報が存在しない為、ユーザー情報を表示できません。";
				cmd = "menu";
				return;
			}

			//エラー処理
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー情報を表示できません。";
			cmd = "logout";

		}finally {
			if(error.equals("")) {
				request.setAttribute("userinfo", user);
				request.setAttribute("address", address);
				request.getRequestDispatcher("/view/myPage.jsp").forward(request, response);

			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);

				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}

