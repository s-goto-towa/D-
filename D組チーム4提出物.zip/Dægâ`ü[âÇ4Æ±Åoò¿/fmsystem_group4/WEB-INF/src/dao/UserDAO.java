package dao;

import java.sql.*;
import java.util.ArrayList;

import com.sun.javafx.geom.transform.GeneralTransform3D;

import bean.User;

public class UserDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/fmdb_group4";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// ユーザー情報を読みだす
	public ArrayList<User> selectAll() {

		// データベース接続のための変数を宣言
		Connection con = null;
		Statement smt = null;

		// UserクラスのArrayListを作成
		ArrayList<User> user_list = new ArrayList<User>();

		try {
			// 検索を行うSQL文を宣言する
			String sql = "SELECT * FROM userinfo";

			// データベース接続を行う
			con = getConnection();
			smt = con.createStatement();

			// SQL文を発行する
			ResultSet rs = smt.executeQuery(sql);

			// 検索したデータを全て格納するまで繰り返す
			while (rs.next()) {
				User user = new User();
				user.setUser_id(rs.getString("user_id"));
				user.setPassword(rs.getString("password"));
				user.setAuthority(rs.getInt("authority"));
				user.setLast_name(rs.getString("last_name"));
				user.setLast_namekana(rs.getString("last_namekana"));
				user.setFirst_name(rs.getString("first_name"));
				user.setFirst_namekana(rs.getString("first_namekana"));
				user.setBirthday(rs.getString("birthday"));
				user.setMail_address(rs.getString("mail_address"));
				user.setProfits(rs.getInt("profits"));
				user.setGoods_id(rs.getInt("goods_id"));
				user.setNickname(rs.getString("nickname"));
				user.setCreate_date(rs.getString("create_date"));
				user.setUpdate_date(rs.getString("update_date"));

				user_list.add(user);
			}
			// エラー処理
		} catch (Exception e) {
			throw new IllegalStateException(e);

			// データベース接続を終了する
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		// userを返す
		return user_list;
	}

	//ユーザー情報を読みだす
	public User selectByUser(String user_id) {

		//データベース接続のための変数を宣言
		Connection con = null;
		Statement smt = null;

		//検索結果を格納するArrayListを宣言
		User user = new User();

		try {
			//検索を行うSQL文を宣言する
			String sql = "SELECT * FROM userinfo WHERE user_id ='" +user_id+ "'";

			//データベース接続を行う
			con = getConnection();
			smt = con.createStatement();

			//SQL文を発行する
			ResultSet rs = smt.executeQuery(sql);

			//検索したデータを全て格納するまで繰り返す
			while(rs.next()) {
				user.setUser_id(rs.getString("user_id"));
				user.setPassword(rs.getString("password"));
				user.setAuthority(rs.getInt("authority"));
				user.setLast_name(rs.getString("last_name"));
				user.setLast_namekana(rs.getString("last_namekana"));
				user.setFirst_name(rs.getString("first_name"));
				user.setFirst_namekana(rs.getString("first_namekana"));
				user.setBirthday(rs.getString("birthday"));
				user.setMail_address(rs.getString("mail_address"));
				user.setProfits(rs.getInt("profits"));
				user.setGoods_id(rs.getInt("goods_id"));
				user.setNickname(rs.getString("nickname"));
				user.setCreate_date(rs.getString("create_date"));
				user.setUpdate_date(rs.getString("update_date"));
			}
			//エラー処理
		}catch(Exception e){
			throw new IllegalStateException(e);

			//データベース接続を終了する
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		//userを返す
		return user;
	}

	//新規ユーザー情報を登録する
	public void insertUserFirst(User user) {

		//データベース接続のための変数を宣言
		Connection con = null;
		Statement smt = null;

		//登録結果を格納する変数を宣言
		int count = 0;

		//登録を行うSQL文
		String sql = "INSERT INTO userinfo(user_id,password,authority,last_name,last_namekana,"
				+ "first_name,first_namekana,birthday,mail_address,nickname,create_date) VALUES('"
				+user.getUser_id()+ "','"
				+user.getPassword()+ "',2,'"
				+user.getLast_name()+ "','"
				+user.getLast_namekana()+ "','"
				+user.getFirst_name()+ "','"
				+user.getFirst_namekana()+ "','"
				+user.getBirthday()+ "','"
				+user.getMail_address()+ "','"
				+user.getNickname()+ "',NOW())";

		try {
			//データベース接続を行う
			con = getConnection();
			smt = con.createStatement();

			//SQL文を発行する
			count = smt.executeUpdate(sql);

			//エラー処理
		}catch(Exception e) {
			throw new IllegalStateException(e);

			//データベース接続を終了する
		}finally {
			if(smt != null) {
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null) {
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	//利益を更新するメソッド
		public void updateProfits(String seller_id, int profits, int price) {

			Connection con = null;
			Statement smt = null;

			//利益を計算
			int lastprofits = (int)(profits + ((price -400)*0.1));

			// SQL文
			String sql = "UPDATE userinfo SET profits = " +lastprofits+ " WHERE user_id = '" + seller_id + "'";

			try {
				con = getConnection();
				smt = con.createStatement();
				// SQL文を発行
				smt.executeUpdate(sql);

			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}
			}
		}

}
